package com.example.ai_speaking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
