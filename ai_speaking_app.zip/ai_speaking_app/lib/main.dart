import 'package:flutter/material.dart';
import 'services/openai_service.dart';
import 'services/did_service.dart';
import 'services/voice_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final OpenAIService _openAI = OpenAIService();
  final DIDService _did = DIDService();
  final VoiceService _voice = VoiceService();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("AI Speaking App")),
        body: Center(
          child: ElevatedButton(
            onPressed: () async {
              String? userSpeech = await _voice.listen();
              if (userSpeech != null) {
                String aiResponse = await _openAI.getAIResponse(userSpeech);
                await _voice.speak(aiResponse);
                String animationId = await _did.generateAnimation(aiResponse);
                print("Анимация создана: $animationId");
              }
            },
            child: Text("Говорить"),
          ),
        ),
      ),
    );
  }
}
