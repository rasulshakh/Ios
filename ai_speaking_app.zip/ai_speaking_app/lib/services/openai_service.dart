import 'package:dio/dio.dart';

class OpenAIService {
  final Dio _dio = Dio(BaseOptions(
    baseUrl: 'https://api.openai.com/v1',
    headers: {'Authorization': 'Bearer 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'},
  ));

  Future<String> getAIResponse(String text) async {
    try {
      final response = await _dio.post('/chat/completions', data: {
        'model': 'gpt-4',
        'messages': [{'role': 'user', 'content': text}],
      });
      return response.data['choices'][0]['message']['content'];
    } catch (e) {
      return "Ошибка AI: $e";
    }
  }
}
