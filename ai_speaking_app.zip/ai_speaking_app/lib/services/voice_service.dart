import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

class VoiceService {
  final FlutterTts _tts = FlutterTts();
  final SpeechToText _speech = SpeechToText();

  Future<void> speak(String text) async {
    await _tts.speak(text);
  }

  Future<String?> listen() async {
    bool available = await _speech.initialize();
    if (available) {
      await _speech.listen();
      return _speech.lastRecognizedWords;
    }
    return null;
  }
}
