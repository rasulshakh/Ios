import 'package:dio/dio.dart';

class DIDService {
  final Dio _dio = Dio(BaseOptions(
    baseUrl: 'https://api.d-id.com',
    headers: {'Authorization': 'Bearer cmFzdWwxMzEyOThAZ21haWwuY29t:q2NuKJuN-TL7ne-rwjxfV'},
  ));

  Future<String> generateAnimation(String text) async {
    try {
      final response = await _dio.post('/talks', data: {
        'script': {'type': 'text', 'input': text, 'provider': 'openai'},
        'source_url': 'URL_КАРТИНКИ_ПЕРСОНАЖА'
      });
      return response.data['id'];
    } catch (e) {
      return "Ошибка D-ID: $e";
    }
  }
}
